=== Restaurateur Menu Item CPT ===
Contributors: WPThemes.co.nz
Tags: custom post type, menu item, shortcode
Requires at least: 3.2
Tested up to: 3.5.2
Stable tag: 1.0

== Description ==

Creates "Menu Item" custom post type for the Restaurateur theme.

== Installation ==

1. Upload the Restaurateur Menu Item CPT plugin folder to the '/wp-content/plugins/' directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.

== Changelog ==

= 1.0 =
* First release